package org.acme.model;

public class T_LOGIN {
}
